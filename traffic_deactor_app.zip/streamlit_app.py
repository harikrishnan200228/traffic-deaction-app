import streamlit as st
import joblib
import numpy as np

st.set_page_config(page_title="Traffic Attack Detector", layout="centered")
st.title("🚦 Embedded System Network Attack Detector")

model = joblib.load("random_forest_model.pkl")

st.markdown("Enter the network traffic features below:")

packet_size = st.number_input("Packet Size", min_value=0, value=1500)
inter_arrival_time = st.number_input("Inter-Arrival Time", min_value=0.0, format="%.6f", value=0.001)
src_port = st.number_input("Source Port", min_value=0, value=4444)
dst_port = st.number_input("Destination Port", min_value=0, value=80)
packet_count_5s = st.number_input("Packet Count (5s)", min_value=0, value=2000)
mean_packet_size = st.number_input("Mean Packet Size", min_value=0, value=1400)
spectral_entropy = st.slider("Spectral Entropy", 0.0, 1.0, 0.95)
frequency_band_energy = st.slider("Frequency Band Energy", 0.0, 1.0, 0.90)

protocol_type_TCP = st.checkbox("Protocol: TCP", value=True)
protocol_type_UDP = st.checkbox("Protocol: UDP", value=False)
src_ip_1 = st.checkbox("Source IP: 192.168.1.2", value=False)
src_ip_2 = st.checkbox("Source IP: 192.168.1.3", value=False)
dst_ip_1 = st.checkbox("Destination IP: 192.168.1.5", value=True)
dst_ip_2 = st.checkbox("Destination IP: 192.168.1.6", value=False)
tcp_flag_fin = st.checkbox("TCP Flag: FIN", value=False)
tcp_flag_syn = st.checkbox("TCP Flag: SYN", value=True)
tcp_flag_synack = st.checkbox("TCP Flag: SYN-ACK", value=False)

input_data = np.array([[
    packet_size, inter_arrival_time, src_port, dst_port,
    packet_count_5s, mean_packet_size, spectral_entropy, frequency_band_energy,
    int(protocol_type_TCP), int(protocol_type_UDP),
    int(src_ip_1), int(src_ip_2), int(dst_ip_1), int(dst_ip_2),
    int(tcp_flag_fin), int(tcp_flag_syn), int(tcp_flag_synack)
]])

if st.button("🔍 Predict"):
    prediction = model.predict(input_data)
    if prediction[0] == 1:
        st.error("⚠️ Attack Detected")
    else:
        st.success("✅ Benign Traffic")