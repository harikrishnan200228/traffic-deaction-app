# 🚦 Embedded System Network Attack Detector

This Streamlit web app detects potential cyber-attacks in embedded system traffic using a trained machine learning model.

## 🚀 How It Works

- Trained on real network traffic dataset
- Accepts input features like packet size, protocol, flags, etc.
- Predicts whether the traffic is benign or malicious

## 🧠 Model Info

- Model: Random Forest Classifier
- Trained with `retrain_model.py`

## 📦 Installation

Clone the repo and install dependencies:
```bash
git clone https://github.com/your-username/traffic_deactor_app.git
cd traffic_deactor_app
pip install -r requirements.txt
```

## ▶️ Running the App

```bash
streamlit run streamlit_app.py
```

## 📁 Files

| File                 | Description                       |
|----------------------|-----------------------------------|
| `streamlit_app.py`   | UI and prediction code            |
| `retrain_model.py`   | Model training                    |
| `random_forest_model.pkl` | Trained ML model           |
| `requirements.txt`   | Python dependencies               |
| `embedded_system_network_security_dataset.csv` | Dataset |